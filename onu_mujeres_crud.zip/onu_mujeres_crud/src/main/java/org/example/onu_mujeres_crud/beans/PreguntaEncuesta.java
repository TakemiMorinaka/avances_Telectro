package org.example.onu_mujeres_crud.beans;

public class PreguntaEncuesta {
    private Integer encuestaId;
    private Integer preguntaId;
    private Integer orden;

    public PreguntaEncuesta() {
    }

    public Integer getEncuestaId() {
        return encuestaId;
    }

    public void setEncuestaId(Integer encuestaId) {
        this.encuestaId = encuestaId;
    }

    public Integer getPreguntaId() {
        return preguntaId;
    }

    public void setPreguntaId(Integer preguntaId) {
        this.preguntaId = preguntaId;
    }

    public Integer getOrden() {
        return orden;
    }

    public void setOrden(Integer orden) {
        this.orden = orden;
    }

    // Importante: Como esta tabla tiene una clave primaria compuesta,
    // podrías considerar crear una clase separada para la clave primaria
    // e implementar equals() y hashCode() si vas a usarla en colecciones.
}