package org.example.onu_mujeres_crud.beans;
import java.time.LocalDateTime;

public class Encuesta {
    private Integer encuestaId;
    private String nombre;
    private String descripcion;
    private String carpeta;
    private Integer usuarioCreadorId;
    private String estado; // ENUM('activo', 'inactivo')
    private LocalDateTime fechaCreacion;
    private LocalDateTime fechaModificacion;

    public Encuesta() {
    }

    public Integer getEncuestaId() {
        return encuestaId;
    }

    public void setEncuestaId(Integer encuestaId) {
        this.encuestaId = encuestaId;
    }

    public String getNombre() {
        return nombre;
    }

    public void setNombre(String nombre) {
        this.nombre = nombre;
    }

    public String getDescripcion() {
        return descripcion;
    }

    public void setDescripcion(String descripcion) {
        this.descripcion = descripcion;
    }

    public String getCarpeta() {
        return carpeta;
    }

    public void setCarpeta(String carpeta) {
        this.carpeta = carpeta;
    }

    public Integer getUsuarioCreadorId() {
        return usuarioCreadorId;
    }

    public void setUsuarioCreadorId(Integer usuarioCreadorId) {
        this.usuarioCreadorId = usuarioCreadorId;
    }

    public String getEstado() {
        return estado;
    }

    public void setEstado(String estado) {
        this.estado = estado;
    }

    public LocalDateTime getFechaCreacion() {
        return fechaCreacion;
    }

    public void setFechaCreacion(LocalDateTime fechaCreacion) {
        this.fechaCreacion = fechaCreacion;
    }

    public LocalDateTime getFechaModificacion() {
        return fechaModificacion;
    }

    public void setFechaModificacion(LocalDateTime fechaModificacion) {
        this.fechaModificacion = fechaModificacion;
    }
}