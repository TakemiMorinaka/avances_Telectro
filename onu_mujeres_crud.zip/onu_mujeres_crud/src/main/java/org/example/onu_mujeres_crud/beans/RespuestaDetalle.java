package org.example.onu_mujeres_crud.beans;
import java.time.LocalDateTime;

public class RespuestaDetalle {
    private Integer detalleId;
    private Integer respuestaId;
    private Integer preguntaId;
    private Integer opcionId;
    private String respuestaTexto;
    private LocalDateTime fechaContestacion;

    public RespuestaDetalle() {
    }

    public Integer getDetalleId() {
        return detalleId;
    }

    public void setDetalleId(Integer detalleId) {
        this.detalleId = detalleId;
    }

    public Integer getRespuestaId() {
        return respuestaId;
    }

    public void setRespuestaId(Integer respuestaId) {
        this.respuestaId = respuestaId;
    }

    public Integer getPreguntaId() {
        return preguntaId;
    }

    public void setPreguntaId(Integer preguntaId) {
        this.preguntaId = preguntaId;
    }

    public Integer getOpcionId() {
        return opcionId;
    }

    public void setOpcionId(Integer opcionId) {
        this.opcionId = opcionId;
    }

    public String getRespuestaTexto() {
        return respuestaTexto;
    }

    public void setRespuestaTexto(String respuestaTexto) {
        this.respuestaTexto = respuestaTexto;
    }

    public LocalDateTime getFechaContestacion() {
        return fechaContestacion;
    }

    public void setFechaContestacion(LocalDateTime fechaContestacion) {
        this.fechaContestacion = fechaContestacion;
    }
}