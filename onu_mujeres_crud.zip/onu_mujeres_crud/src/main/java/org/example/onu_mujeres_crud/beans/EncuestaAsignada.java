package org.example.onu_mujeres_crud.beans;
import java.time.LocalDateTime;

public class EncuestaAsignada {
    private Integer asignacionId;
    private Integer encuestaId;
    private Integer encuestadorId;
    private Integer coordinadorId;
    private String estado; // ENUM('activo', 'revocado', 'completado')
    private LocalDateTime fechaAsignacion;
    private LocalDateTime fechaCompletado;

    public EncuestaAsignada() {
    }

    public Integer getAsignacionId() {
        return asignacionId;
    }

    public void setAsignacionId(Integer asignacionId) {
        this.asignacionId = asignacionId;
    }

    public Integer getEncuestaId() {
        return encuestaId;
    }

    public void setEncuestaId(Integer encuestaId) {
        this.encuestaId = encuestaId;
    }

    public Integer getEncuestadorId() {
        return encuestadorId;
    }

    public void setEncuestadorId(Integer encuestadorId) {
        this.encuestadorId = encuestadorId;
    }

    public Integer getCoordinadorId() {
        return coordinadorId;
    }

    public void setCoordinadorId(Integer coordinadorId) {
        this.coordinadorId = coordinadorId;
    }

    public String getEstado() {
        return estado;
    }

    public void setEstado(String estado) {
        this.estado = estado;
    }

    public LocalDateTime getFechaAsignacion() {
        return fechaAsignacion;
    }

    public void setFechaAsignacion(LocalDateTime fechaAsignacion) {
        this.fechaAsignacion = fechaAsignacion;
    }

    public LocalDateTime getFechaCompletado() {
        return fechaCompletado;
    }

    public void setFechaCompletado(LocalDateTime fechaCompletado) {
        this.fechaCompletado = fechaCompletado;
    }
}