package org.example.onu_mujeres_crud.beans;

public class Zona {
    private Integer zonaId;
    private String nombre;

    public Zona() {
    }

    public Integer getZonaId() {
        return zonaId;
    }

    public void setZonaId(Integer zonaId) {
        this.zonaId = zonaId;
    }

    public String getNombre() {
        return nombre;
    }

    public void setNombre(String nombre) {
        this.nombre = nombre;
    }
}