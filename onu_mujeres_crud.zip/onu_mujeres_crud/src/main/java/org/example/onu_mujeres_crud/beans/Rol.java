package org.example.onu_mujeres_crud.beans; // Puedes ajustar el nombre del paquete según tu proyecto
import java.time.LocalDateTime;

public class Rol {
    private Integer rolId;
    private String nombre; // ENUM('encuestador', 'coordinador', 'administrador')

    public Rol() {
    }

    public Integer getRolId() {
        return rolId;
    }

    public void setRolId(Integer rolId) {
        this.rolId = rolId;
    }

    public String getNombre() {
        return nombre;
    }

    public void setNombre(String nombre) {
        this.nombre = nombre;
    }
}