package org.example.onu_mujeres_crud.beans;
import java.time.LocalDateTime;

public class Respuesta {
    private Integer respuestaId;
    private Integer encuestaId;
    private Integer encuestadorId;
    private String dniEncuestado;
    private Integer asignacionId;
    private String estado; // ENUM('borrador', 'completo')
    private LocalDateTime fechaInicio;
    private LocalDateTime fechaEnvio;

    public Respuesta() {
    }

    public Integer getRespuestaId() {
        return respuestaId;
    }

    public void setRespuestaId(Integer respuestaId) {
        this.respuestaId = respuestaId;
    }

    public Integer getEncuestaId() {
        return encuestaId;
    }

    public void setEncuestaId(Integer encuestaId) {
        this.encuestaId = encuestaId;
    }

    public Integer getEncuestadorId() {
        return encuestadorId;
    }

    public void setEncuestadorId(Integer encuestadorId) {
        this.encuestadorId = encuestadorId;
    }

    public String getDniEncuestado() {
        return dniEncuestado;
    }

    public void setDniEncuestado(String dniEncuestado) {
        this.dniEncuestado = dniEncuestado;
    }

    public Integer getAsignacionId() {
        return asignacionId;
    }

    public void setAsignacionId(Integer asignacionId) {
        this.asignacionId = asignacionId;
    }

    public String getEstado() {
        return estado;
    }

    public void setEstado(String estado) {
        this.estado = estado;
    }

    public LocalDateTime getFechaInicio() {
        return fechaInicio;
    }

    public void setFechaInicio(LocalDateTime fechaInicio) {
        this.fechaInicio = fechaInicio;
    }

    public LocalDateTime getFechaEnvio() {
        return fechaEnvio;
    }

    public void setFechaEnvio(LocalDateTime fechaEnvio) {
        this.fechaEnvio = fechaEnvio;
    }
}